#sessionInfo()
#load all required package
#https://rpubs.com/vitidN/203264

library(arules)
library(dplyr)
library(reshape2)
library(Matrix)
library(stringr)
library(stringdist)
library(ggplot2)
#install.packages("stringdist")

setwd("C:\\Classes\\Sem2_jul_to_dec_2017\\WebAnalytics\\Project1\\V1")

movies = read.csv("movies.DAT", 
                  #colClasses = c("integer","character","character"),
                  sep = "|",
                  stringsAsFactors = FALSE, header = FALSE)

head(movies)

movies$year = as.numeric(str_sub( str_trim(movies$V2) ,start = -5,end = -2))
movies$year
head(movies)
colnames(movies) <- c("MovieID", "MovieTitle", "Genres","Year")
head(movies)

# Discard Movie ID which does not ahving a Year
discard_movie_id = which(is.na(movies$Year))
discard_movie_id
#display discarded movies
movies$MovieTitle[discard_movie_id]
head(movies)
#movies = movies[-discard_movie_id,]
head(movies)


# Removing the year from  Movie Title
movies$MovieTitle = str_sub( str_trim(movies$MovieTitle) ,start = 1,end = -8)
movies$MovieTitle
head(movies$MovieTitle)

# Preaparing Unique Genres

all_genres = unique(unlist(str_split(movies$Genres,"\\,")))

all_genres

head(movies)

# Filtering the Movie ID which doesn not have Genres
movies %>% filter(str_detect(all_genres,"(no genres listed)") ) %>% nrow()

for(genre in all_genres){
  movies[str_c("genre_",genre)] = ifelse(( str_detect(movies$Genres,genre) | str_detect(movies$Genres,"no genres") ) , 1 , 0)
}
head(movies)

# Data loaded with Movei ID , Movie Title along with Genres
write.csv(movies, file = "MovieLensData.csv")


#check the result
head(movies)
tail(movies)
#Distinct years :: unique(movies$Year)
ggplot(movies,aes(x=Year))  + geom_bar() + ggtitle("Number of Movies")+ xlim(1920,2000) 

##############################
#Ratins
##############################
# Clean ratings
genre_dist = colSums(movies[,5:21])
genre_dist_df = data.frame(genre = names(genre_dist),count = genre_dist)
genre_dist_df$genre = factor(genre_dist_df$genre,levels = names(sort(genre_dist,decreasing = FALSE)))

ggplot(genre_dist_df,aes(x=genre,y=count,fill=genre)) + 
  geom_bar(stat = "identity") + 
  coord_flip() + 
  ggtitle("Genre Distribution") + 
  theme(legend.position = "none")


#Construct Association Rules from Rating Data
ratings = read.csv("ratings.dat",
                   colClasses = c("integer","integer","integer","NULL"),
                   sep=",",
                   stringsAsFactors = FALSE)

head(ratings)
ratings = ratings %>% filter(! MovieID %in% discard_movie_id )
dim(ratings)[1]
#convert rating-per-row dataframe into sparse User-Item matrix
user_item_matrix <- as(split(ratings[,"MovieID"], ratings[,"userId"]), "transactions")

write.csv(user_item_matrix, file = "user_item_matrix.csv") 

#Construct User data 
users = read.csv("users.dat",
                 colClasses = c("integer","character","integer","integer","character"),
                 sep="|",
                 stringsAsFactors = FALSE)

head(users)

#investigate the User-Item matrix
#transactions (rows) -> number of raters
#items (columns) -> number of movies
user_item_matrix

# Setting the Rule Paramter for Support Confidence 
rule_param = list(
  supp = 0.001,
  conf = 0.7,
  maxlen = 2
)

# Assocaition Rules using Apriori
assoc_rules = apriori(user_item_matrix,parameter = rule_param)
summary(assoc_rules)

head(user_item_matrix)
assoc_rules = subset(assoc_rules, lift >= 4.323)
summary(assoc_rules)

# We cast assoc_rules to data.frame and look at some of the data
assoc_rules = as(assoc_rules,"data.frame")

head(assoc_rules)
write.csv(assoc_rules, file = "assoc_rules.csv") 

# The rules still contain movieId. We split movies in both sides to a new column


#############################
#What were the best movies based on users' ratings)?
install.packages("registerDoMC")
library(tidyverse)
library(lubridate)
library(stringr)
library(rvest)
library(XML)
library(tidytext)
library(wordcloud)
library(doMC)
registerDoMC()
set.seed(1234)


summary(ratings)

# average rating for a movie
movie_rating <- ratings %>%
  inner_join(movies, by = "MovieID") %>%
  na.omit() %>%
  select(MovieID, MovieTitle, rating, Year) %>%
  group_by(MovieID, MovieTitle, Year) %>%
  summarise(count = n(), mean = mean(rating)) %>%
  ungroup() %>%
  arrange(desc(mean))

knitr::kable(head(movie_rating, 10))
write.csv(avg_rating, file = "movie_rating.csv") 



# Effect of occupation On Ratings
occupation_ratings <- ratings %>%
  inner_join(users, by = "userId") %>%
  na.omit() %>%
  select(userId, Gender, Occupation, MovieID, rating) %>%
  group_by(Occupation) %>%
  summarise(count = n(), mean = mean(rating)) %>%
  ungroup() %>%
  arrange(order(count))

knitr::kable(head(occupation_ratings, 10))

write.csv(occupation_ratings, file = "occupation_ratings.csv")

# Plot Effect of occupation On Ratings
ggplot(occupation_ratings,aes(x=Occupation,y=count,fill=Occupation)) + 
  geom_bar(stat = "identity") + 
  coord_flip() + 
  #axis(side=2, at=seq(0,600,by=100)) +
  ggtitle("Occupation Demographic Distribution") + 
  theme(legend.position = "right")

# Effect of Age on ratings
age_ratings <- users %>%
  inner_join(ratings, by = "userId") %>%
  na.omit() %>%
  select(userId, Age, Occupation, MovieID, rating)  %>%
  group_by(Age) %>%
  summarise(count = n()) %>%
  ungroup() %>%
  arrange(order(Age))

knitr::kable(head(age_ratings, 10))

# Plot age and rating counts
ggplot(age_ratings,aes(x=Age,y=count,fill=Age)) + 
  geom_bar(stat = "identity") + 
  coord_flip() + 
  # ylim(20000,200000) +
  ggtitle("Age Distribution") + 
  theme(legend.position = "none")


####################Mohan

# Effect of Age on ratings
age_ratings <- users %>%
  inner_join(ratings, by = "userId") %>%
  filter(rating >= 5 ) %>%
  na.omit() %>%
  select(userId, Age, Occupation, MovieID, rating)  %>%
  group_by(Age) %>%
  summarise(count = n()) %>%
  ungroup() %>%
  arrange(order(Age))

knitr::kable(head(age_ratings, 10))


#=================
age_ratings1 <- ratings %>%
  inner_join(users, by = "userId") %>%
  inner_join(movies, by = "MovieID") %>%
  na.omit() %>%
  select(userId, Age, Occupation, MovieID, MovieTitle, rating)  %>%
  #group_by(Age) %>%
  summarise(count = n()) %>%
  ungroup() %>%
 #arrange(order(Age))

knitr::kable(head(age_ratings1, 10))


# average rating for a movie
movie_rating <- ratings %>%
  inner_join(movies, by = "MovieID") %>%
  na.omit() %>%
  select(MovieID, MovieTitle, rating, Year) %>%
  group_by(MovieID, MovieTitle, Year) %>%
  summarise(count = n(), mean = mean(rating)) %>%
  ungroup() %>%
  arrange(desc(mean))

knitr::kable(head(movie_rating, 10))
write.csv(avg_rating, file = "movie_rating.csv") 


#convert rating-per-row dataframe into sparse User-Item matrix

user_rating_join <- merge(ratings, users, by="userId")
user_rating_movies_join <- merge(user_rating_join, movies, by="MovieID")

train_data = subset(user_rating_movies_join, userId < 4500)
write.csv(train_data, file = "train_data.csv") 
test_data = subset(user_rating_movies_join, userId >= 4500)
write.csv(test_data, file = "test_data.csv") 

ratings_100k = read.csv("ratings_100k.csv",
                 colClasses = c("integer","integer","integer","integer"),
                 sep=",",
                 stringsAsFactors = FALSE)

train_data_100k = subset(ratings_100k, user_id < 600)
write.csv(train_data_100k, file = "train_data_100k.csv") 
test_data_100k = subset(ratings_100k, user_id >= 600)
write.csv(test_data_100k, file = "test_data_100k.csv") 

trainegs = read.transactions(file = "train_data_100k.csv",rm.duplicates=TRUE, format="single", sep=",", cols=c("movie_id","user_id"));
rules <- apriori(trainegs, parameter = list(supp=0.01, conf=0.1, minlen=2))
summary(rules)
inspect(rules)

#read the test data
testegs = read.csv(file="test_data_1k.csv");
colnames(testegs) <- c("basketID","items") 

#execute rules against test data
rulesDF = as(rules,"data.frame")
testegs$preds = apply(testegs,1,function(X) makepreds(X["items"], rulesDF))

# extract unique predictions for each test user
userpreds = as.data.frame(aggregate(preds ~ basketID, data = testegs, paste, collapse=","))
userpreds$preds = apply(userpreds,1,function(X) uniqueitems(X["preds"]))

# extract unique items bought (or rated highly) for each test user
baskets = as.data.frame(aggregate(items ~ basketID, data = testegs, paste, collapse=","))
baskets$items = apply(baskets,1,function(X) uniqueitems(X["items"]))

#count how many unique predictions made are correct, i.e. have previously been bought (or rated highly) by the user
correctpreds = sum(apply(userpreds,1,function(X) checkpreds(X["preds"],X["basketID"])))

# count total number of unique predictions made
totalpreds = sum(apply(userpreds,1,function(X) countpreds(X["preds"][[1]]))) 
precision = correctpreds*100/totalpreds
cat("precision=", precision, "corr=",correctpreds,"total=",totalpreds)




#######################################################################
# the supporting functions
#######################################################################

#remove duplicate items from a basket (itemstrg)
uniqueitems <- function(itemstrg) {
  unique(as.list(strsplit(gsub(" ","",itemstrg),","))[[1]])
}

# execute ruleset using item as rule antecedent (handles single item antecedents only)
makepreds <- function(item, rulesDF) {
  antecedent = paste("{",item,"} =>",sep="") 
  print(antecedent)
  firingrules = rulesDF[grep(antecedent, rulesDF$rules,fixed=TRUE),1]
  gsub(" ","",toString(sub("\\}","",sub(".*=> \\{","",firingrules))))
}

# count how many predictions are in the basket of items already seen by that user 
# Caution : refers to "baskets" as a global
checkpreds <- function(preds, baskID) {
  plist = preds[[1]]
  blist = baskets[baskets$basketID == baskID,"items"][[1]]
  cnt = 0 
  for (p in plist) {
    if (p %in% blist) cnt = cnt+1
  }
  cnt
}

# count all predictions made
countpreds <- function(predlist) {
  len = length(predlist)
  if (len > 0 && (predlist[[1]] == "")) 0 # avoid counting an empty list
  else len
}












##############Not used below code
user_item_matrix_all <- as(split(user_rating_movies_join[,"MovieID"], user_rating_movies_join[,"userId"],
                             user_rating_movies_join[,"Age"], user_rating_movies_join[,"Occupation"],
                             user_rating_movies_join[,"Gender"]), "transactions")

# Assocaition Rules using Apriori
rule_param_all = list(
  supp = 0.001,
  conf = 0.7,
  maxlen = 5
)
assoc_rules_all = apriori(user_item_matrix_all,parameter = rule_param_all)
summary(assoc_rules_all)

head(user_item_matrix_all)
assoc_rules_all = subset(assoc_rules_all, lift >= 4.323)
summary(assoc_rules_all)